replaceitem entity @s container.11 apple{display:{Name:"[{\"text\":\"Play UHC \",\"color\":\"white\"},{\"text\":\" - \",\"color\":\"dark_gray\"},{\"text\":\"Casual\",\"color\":\"dark_green\",\"bold\":true}]",Lore:["{\"text\":\"Border Size: 1k x 1k\",\"color\":\"dark_gray\"}","{\"text\":\"Player Cap: 12\",\"color\":\"dark_gray\"}"]},Enchantments:[{}],objd:{gui:1b}} 
replaceitem entity @s container.13 grass_block{display:{Name:"[{\"text\":\"Play UHC \",\"color\":\"white\"},{\"text\":\" - \",\"color\":\"dark_gray\"},{\"text\":\"MEGA\",\"color\":\"gold\",\"bold\":true}]",Lore:["{\"text\":\"Border Size: 10k x 10k\",\"color\":\"dark_gray\"}","{\"text\":\"Player Cap: UNLIMITED\",\"color\":\"dark_gray\"}"]},Enchantments:[{}],objd:{gui:1b}} 
replaceitem entity @s container.15 golden_apple{display:{Name:"[{\"text\":\"Play UHC \",\"color\":\"white\"},{\"text\":\" - \",\"color\":\"dark_gray\"},{\"text\":\"Meetup\",\"color\":\"blue\",\"bold\":true}]",Lore:["{\"text\":\"Border Size: 32 x 32\",\"color\":\"dark_gray\"}","{\"text\":\"Player Cap: 12\",\"color\":\"dark_gray\"}"]},Enchantments:[{}],objd:{gui:1b}} 
replaceitem entity @s container.0 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 
replaceitem entity @s container.1 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 
replaceitem entity @s container.2 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 
replaceitem entity @s container.3 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 
replaceitem entity @s container.4 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 
replaceitem entity @s container.5 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 
replaceitem entity @s container.6 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 
replaceitem entity @s container.7 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 
replaceitem entity @s container.8 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 
replaceitem entity @s container.9 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 
replaceitem entity @s container.10 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 
replaceitem entity @s container.12 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 
replaceitem entity @s container.14 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 
replaceitem entity @s container.16 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 
replaceitem entity @s container.17 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 
replaceitem entity @s container.18 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 
replaceitem entity @s container.19 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 
replaceitem entity @s container.20 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 
replaceitem entity @s container.21 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 
replaceitem entity @s container.22 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 
replaceitem entity @s container.23 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 
replaceitem entity @s container.24 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 
replaceitem entity @s container.25 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 
replaceitem entity @s container.26 gray_stained_glass_pane{display:{Name:"{\"text\":\" \"}"},objd:{gui:1b}} 