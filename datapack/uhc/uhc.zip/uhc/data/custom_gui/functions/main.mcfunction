execute as @a[nbt={SelectedItem:{id:"minecraft:chest",tag:{display:{Name:"{\"text\":\"Choose A UHC Gamemode\",\"color\":\"gold\",\"bold\":true}"},Enchantments:[{}]}}}] run tag @s add objd_has_gui_item
execute as @e[type=minecraft:chest_minecart,tag=objd_gui_container] at @s run execute unless entity @e[distance=..8,tag=objd_has_gui_item] run function custom_gui:gui/removecart
execute as @e[tag=objd_had_gui_item,tag=!objd_has_gui_item] run tag @s remove objd_had_gui_item
execute as @a[tag=objd_has_gui_item,tag=!objd_had_gui_item] at @s anchored eyes run function custom_gui:gui/summoncart
execute as @a[tag=objd_has_gui_item] at @s anchored eyes run function custom_gui:objd/execute2
execute as @e[type=minecraft:chest_minecart,tag=objd_gui_container] at @s run function custom_gui:gui/main