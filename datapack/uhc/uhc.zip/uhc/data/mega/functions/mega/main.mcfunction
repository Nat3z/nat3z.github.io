scoreboard players add Timer mega-Timers 1

execute if score Timer mega-Timers matches 4000 run effect give @a minecraft:instant_health 1 50
execute if score Timer mega-Timers matches 4000 run effect give @a minecraft:saturation 1 50
execute if score Timer mega-Timers matches 4000 run effect clear @a minecraft:fire_resistance
execute if score Timer mega-Timers matches 4000 run effect clear @a minecraft:absorption
execute if score Timer mega-Timers matches 4000 run tellraw @a [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" Final Heal Distributed And Grace Period Ended","color":"white"}]
 
execute if score Timer mega-Timers matches 5800 run tellraw @a [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" PVP Will Be Enabled In 10","color":"white"}]

execute if score Timer mega-Timers matches 5820 run tellraw @a [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" PVP Will Be Enabled In 9","color":"white"}]

execute if score Timer mega-Timers matches 5840 run tellraw @a [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" PVP Will Be Enabled In 8","color":"white"}]

execute if score Timer mega-Timers matches 5860 run tellraw @a [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" PVP Will Be Enabled In 7","color":"white"}]

execute if score Timer mega-Timers matches 5880 run tellraw @a [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" PVP Will Be Enabled In 6","color":"white"}]

execute if score Timer mega-Timers matches 5900 run tellraw @a [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" PVP Will Be Enabled In 5","color":"white"}]

execute if score Timer mega-Timers matches 5920 run tellraw @a [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" PVP Will Be Enabled In 4","color":"white"}]

execute if score Timer mega-Timers matches 5940 run tellraw @a [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" PVP Will Be Enabled In 3","color":"white"}]

execute if score Timer mega-Timers matches 5960 run tellraw @a [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" PVP Will Be Enabled In 2","color":"white"}]

execute if score Timer mega-Timers matches 5980 run tellraw @a [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" PVP Will Be Enabled In 1","color":"white"}]

execute if score Timer mega-Timers matches 6000 run team remove all
execute if score Timer mega-Timers matches 6000 run tellraw @a [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" PVP Is Now Enabled","color":"white"}]

execute if score Timer mega-Timers matches 8000 run worldborder set 5000 100
execute if score Timer mega-Timers matches 8000 run tellraw @a [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" Worldborder Now Shrinking To 5000x5000 in 100s","color":"white"}]

execute if score Timer mega-Timers matches 12000 run worldborder set 1000 300
execute if score Timer mega-Timers matches 12000 run tellraw @a [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" Worldborder Now Shrinking To 1000x1000 in 300s","color":"white"}]

execute if score Timer mega-Timers matches 18000 run worldborder set 500 300
execute if score Timer mega-Timers matches 18000 run tellraw @a [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" Worldborder Now Shrinking To 500x500 in 300s","color":"white"}]

execute if score Timer mega-Timers matches 24000 run worldborder set 300 200
execute if score Timer mega-Timers matches 24000 run tellraw @a [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" Worldborder Now Shrinking To 300x300 in 200s","color":"white"}]

execute if score Timer mega-Timers matches 28000 run worldborder set 100 600
execute if score Timer mega-Timers matches 28000 run tellraw @a [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" Worldborder Now Shrinking To 100x100 in 600s","color":"white"}]

execute if score Timer mega-Timers matches 34000 run worldborder set 50 20
execute if score Timer mega-Timers matches 34000 run tellraw @a [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" Worldborder Now Shrinking To 50x50 in 20s","color":"white"}]

execute if score Timer mega-Timers matches 35000 run worldborder set 25 20
execute if score Timer mega-Timers matches 35000 run tellraw @a [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" Worldborder Now Shrinking To 25x25 in 20s","color":"white"}]

execute if score Timer mega-Timers matches 37000 run worldborder set 1 200
execute if score Timer mega-Timers matches 37000 run tellraw @a [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" Worldborder Now Shrinking To 1x1 in 200s.","color":"white"},{"text":" FINAL FIGHT","color":"dark_red","bold":"true"}]

execute as @a[scores={mega-death=1..}] run scoreboard players remove players mega-players 1
execute as @a[scores={mega-death=1..}] run scoreboard players reset @s mega-death



execute if score players mega-players matches 1 if score Timer mega-Timers matches 100.. run title @a title {"text":"GG","color":"dark_green"}
execute if score players mega-players matches 1 if score Timer mega-Timers matches 100.. run clear @a
execute as @a if score players mega-players matches 1 if score Timer mega-Timers matches 100.. run replaceitem entity @s hotbar.4 minecraft:chest{display:{Name:'{"text":"Choose A UHC Gamemode","color":"gold","bold":true}'},Enchantments:[{}]}
execute if score players mega-players matches 1 if score Timer mega-Timers matches 100.. run gamemode adventure @a
execute if score players mega-players matches 1 if score Timer mega-Timers matches 100.. run scoreboard objectives remove mega-Timers