recipe give @a uhc:andrul
recipe give @a uhc:bloodlust
recipe give @a uhc:fusionset
recipe give @a uhc:ghead
recipe give @a uhc:healingtalisman
recipe give @a uhc:lavabucket
recipe give @a uhc:quickpick
recipe give @a uhc:dice

effect give @a minecraft:instant_health 1 50
effect give @a minecraft:saturation 1 50

recipe give @a minecraft:enchanted_golden_apple

scoreboard objectives add uhc-mega dummy [{"text":"UHC","color":"gold"},{"text":" - ","color":"dark_gray"},{"text":"MEGA","color":"dark_red"}]
advancement revoke @a everything
worldborder damage amount 100
gamerule fallDamage true
gamemode survival @a


scoreboard objectives remove WorldBordertimer
scoreboard objectives remove FinalHeal


scoreboard players reset players mega-players
scoreboard objectives add mega-players dummy
execute as @a run scoreboard players add players mega-players 1
scoreboard objectives add heads minecraft.custom:minecraft.player_kills
scoreboard objectives add ghead minecraft.used:minecraft.carrot_on_a_stick
scoreboard players reset Heal mega-Timers
scoreboard objectives add mega-death deathCount
scoreboard players reset Timer mega-Timers

team remove all
team add all
team join all @a
team modify all friendlyFire false
scoreboard objectives add mega-Timers dummy
worldborder set 10000 0
spreadplayers 0 ~ 0 1000 false @a

scoreboard objectives setdisplay sidebar uhc-mega

clear @a
effect clear @a

time set day

gamerule doDaylightCycle false

effect give @a minecraft:fire_resistance 1000 0
effect give @a minecraft:absorption 1000 1