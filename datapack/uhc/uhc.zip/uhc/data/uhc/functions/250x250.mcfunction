recipe give @a uhc:andrul
recipe give @a uhc:bloodlust
recipe give @a uhc:fusionset
recipe give @a uhc:ghead
recipe give @a uhc:healingtalisman
recipe give @a uhc:lavabucket
recipe give @a uhc:quickpick
recipe give @a uhc:dice
effect give @a minecraft:instant_health 1 50
effect give @a minecraft:saturation 1 50

recipe give @a minecraft:enchanted_golden_apple


scoreboard objectives add uhc dummy [{"text":"UHC","color":"gold"},{"text":" - ","color":"dark_gray"},{"text":"Casual","color":"dark_aqua"}]
advancement revoke @a everything
worldborder damage amount 100
gamerule fallDamage true
gamemode survival @a
scoreboard players reset players players
scoreboard objectives add players dummy
execute as @a run scoreboard players add players players 1
scoreboard objectives add heads minecraft.custom:minecraft.player_kills
scoreboard objectives add ghead minecraft.used:minecraft.carrot_on_a_stick
scoreboard players reset Heal FinalHeal
scoreboard objectives add death deathCount
team remove all
team add all
team join all @a
team add prefix
team modify prefix prefix {"text":" ","color":"gold"}
team modify all friendlyFire false
scoreboard objectives add WorldBordertimer dummy
scoreboard objectives add FinalHeal dummy
scoreboard players reset Worldborder WorldBordertimer
worldborder set 1000 0
spreadplayers 0 ~ 0 400 false @a

scoreboard objectives setdisplay sidebar uhc

clear @a
effect clear @a

time set day

gamerule doDaylightCycle false