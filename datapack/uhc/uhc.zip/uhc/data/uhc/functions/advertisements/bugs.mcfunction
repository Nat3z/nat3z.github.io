# ADVERT 3 #

execute if score Worldborder WorldBordertimer matches 500 run tellraw @a [{"text":"--------------","color":"dark_red","bold":true},{"text":"\nFind A Bug?"},{"text":"\nReport it In Our Discord","color":"dark_aqua"},{"text":"\nInsert Discord Link Here","color":"gold"},{"text":"\n--------------","color":"dark_red","bold":true}]
execute at @a if score Worldborder WorldBordertimer matches 500 run playsound minecraft:entity.arrow.hit_player block @a

execute if score Worldborder WorldBordertimer matches 2370 run tellraw @a [{"text":"--------------","color":"dark_red","bold":true},{"text":"\nFind A Bug?"},{"text":"\nReport it In Our Discord","color":"dark_aqua"},{"text":"\nInsert Discord Link Here","color":"gold"},{"text":"\n--------------","color":"dark_red","bold":true}]
execute at @a if score Worldborder WorldBordertimer matches 2370 run playsound minecraft:entity.arrow.hit_player block @a