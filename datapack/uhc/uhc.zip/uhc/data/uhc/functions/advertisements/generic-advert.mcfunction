# ADVERT 1 #

execute if score Worldborder WorldBordertimer matches 200 run tellraw @a [{"text":"--------------","color":"dark_red","bold":true},{"text":"\nThis is The Advert"},{"text":"\n--------------","color":"dark_red","bold":true}]
execute if score Worldborder WorldBordertimer matches 200 run playsound minecraft:entity.arrow.hit_player block @a