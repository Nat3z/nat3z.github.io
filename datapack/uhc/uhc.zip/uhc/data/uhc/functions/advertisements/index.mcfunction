function uhc:advertisements/website
function uhc:advertisements/bugs
function uhc:advertisements/scenerios