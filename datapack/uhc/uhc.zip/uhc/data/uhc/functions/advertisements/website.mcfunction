# ADVERT 2 #

execute if score Worldborder WorldBordertimer matches 200 run tellraw @a [{"text":"--------------","color":"dark_red","bold":true},{"text":"\nThis UHC Is Created With"},{"text":"\nVanilla ","color":"dark_aqua"},{"text":" UHC","color":"gold"},{"text":"\n--------------","color":"dark_red","bold":true}]
execute at @a if score Worldborder WorldBordertimer matches 197 run playsound minecraft:entity.arrow.hit_player block @a

execute if score Worldborder WorldBordertimer matches 1900 run tellraw @a [{"text":"--------------","color":"dark_red","bold":true},{"text":"\nThis UHC Is Created With"},{"text":"\nVanilla ","color":"dark_aqua"},{"text":" UHC","color":"gold"},{"text":"\n--------------","color":"dark_red","bold":true}]
execute at @a if score Worldborder WorldBordertimer matches 1900 run playsound minecraft:entity.arrow.hit_player block @a

execute if score Worldborder WorldBordertimer matches 2800 run tellraw @a [{"text":"--------------","color":"dark_red","bold":true},{"text":"\nThis UHC Is Created With"},{"text":"\nVanilla ","color":"dark_aqua"},{"text":" UHC","color":"gold"},{"text":"\n--------------","color":"dark_red","bold":true}]
execute at @a if score Worldborder WorldBordertimer matches 2800 run playsound minecraft:entity.arrow.hit_player block @a