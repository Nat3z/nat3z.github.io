execute if score Worldborder WorldBordertimer matches 100.. if score players players matches 1 run title @a title {"text":"WE HAVE A WINNER!","color":"dark_green","bold":"true"}
execute if score Worldborder WorldBordertimer matches 100.. if score players players matches 1 run title @a subtitle {"text":"GG!!!","color":"dark_green"}
execute if score Worldborder WorldBordertimer matches 100.. if score players players matches 1 as @a[gamemode=survival] run say §6Has Won!!!
execute if score Worldborder WorldBordertimer matches 100.. if score players players matches 1 run clear @a
execute as @a if score Worldborder WorldBordertimer matches 100.. if score players players matches 1 run replaceitem entity @s hotbar.4 minecraft:chest{display:{Name:'{"text":"Choose A UHC Gamemode","color":"gold","bold":true}'},Enchantments:[{}]}
execute as @a if score Worldborder WorldBordertimer matches 100.. if score players players matches 1 run gamemode adventure @a
execute if score Worldborder WorldBordertimer matches 100.. if score players players matches 1 run scoreboard players reset players players