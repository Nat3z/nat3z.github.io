execute as @a[nbt={Inventory:[{id:"minecraft:end_portal_frame"}]}] run loot give @s loot uhc:chests/dice
execute as @a[nbt={Inventory:[{id:"minecraft:end_portal_frame"}]}] run clear @s minecraft:end_portal_frame 1




execute as @a[nbt={Inventory:[{id:"minecraft:mule_spawn_egg"}]}] run effect give @s minecraft:instant_health 1 50
execute as @a[nbt={Inventory:[{id:"minecraft:mule_spawn_egg"}]}] run effect give @s minecraft:saturation 1 50
execute as @a[nbt={Inventory:[{id:"minecraft:mule_spawn_egg"}]}] run tellraw @s [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" Lucky!","color":"gold","bold":"true"},{"text":" You Got A Full Heal For Rolling The Dice!","color":"white","bold":"false"}]
execute as @a[nbt={Inventory:[{id:"minecraft:mule_spawn_egg"}]}] run clear @s minecraft:mule_spawn_egg 1

execute as @a[nbt={Inventory:[{id:"minecraft:debug_stick"}]}] run tellraw @s [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" Unlucky!","color":"dark_red","bold":"true"},{"text":" You rolled The Dice And Lost All Of Your Items!","color":"white","bold":"false"}]
execute as @a[nbt={Inventory:[{id:"minecraft:debug_stick"}]}] run clear @s


execute as @a[nbt={Inventory:[{id:"minecraft:spider_spawn_egg"}]}] run give @s enchanted_book{StoredEnchantments:[{id:"minecraft:protection",lvl:4s},{id:"minecraft:sharpness",lvl:4s},{id:"minecraft:unbreaking",lvl:2s},{id:"minecraft:infinity",lvl:1s}]} 1
execute as @a[nbt={Inventory:[{id:"minecraft:spider_spawn_egg"}]}] run tellraw @s [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" Lucky!","color":"gold","bold":"true"},{"text":" You rolled The Dice And Got A God Book!","color":"white","bold":"false"}]
execute as @a[nbt={Inventory:[{id:"minecraft:spider_spawn_egg"}]}] run clear @s minecraft:spider_spawn_egg 1

execute as @a[nbt={Inventory:[{id:"minecraft:piglin_spawn_egg"}]}] run give @s minecraft:potion{CustomPotionEffects:[{Id:10,Amplifier:1,Duration:400},{Id:11,Amplifier:1,Duration:3600},{Id:22,Amplifier:1,Duration:4800}],CustomPotionColor:2996414,display:{Name:"\"Holy Water\""}} 1
execute as @a[nbt={Inventory:[{id:"minecraft:piglin_spawn_egg"}]}] run tellraw @s [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" CRAZY RARE DROP","color":"light_purple","bold":"true"},{"text":" You rolled The Dice And Got Holy Water","color":"white","bold":"false"}]
execute as @a[nbt={Inventory:[{id:"minecraft:piglin_spawn_egg"}]}] run clear @s minecraft:piglin_spawn_egg 1

execute as @a[nbt={Inventory:[{id:"minecraft:shulker_shell"}]}] run tellraw @s [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" WIERD DROP","color":"dark_gray","bold":"true"},{"text":" You rolled The Dice And Gave A Random Person A Trident","color":"white","bold":"false"}]
execute as @a[nbt={Inventory:[{id:"minecraft:shulker_shell"}]}] run give @r minecraft:trident 1
execute as @a[nbt={Inventory:[{id:"minecraft:shulker_shell"}]}] run clear @s minecraft:shulker_shell 1

execute as @a[nbt={Inventory:[{id:"minecraft:glistering_melon_slice"}]}] run tellraw @s [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" UNLUCKY","color":"dark_red","bold":"true"},{"text":" You rolled The Dice And Teleported To A Random Player","color":"white","bold":"false"}]
execute as @a[nbt={Inventory:[{id:"minecraft:glistering_melon_slice"}]}] run tp @s @r
execute as @a[nbt={Inventory:[{id:"minecraft:glistering_melon_slice"}]}] run clear @s minecraft:glistering_melon_slice 1

execute as @a[nbt={Inventory:[{id:"minecraft:zombie_spawn_egg"}]}] run tellraw @a [{"text":"<","color":"dark_gray"},{"text":"UHC","color":"gold"},{"text":">","color":"dark_gray"},{"text":" CRAZY UNLUCKY","color":"red","bold":"true"},{"text":" Someone rolled The Dice And Summoned The Wither","color":"white","bold":"false"}]
execute at @a[nbt={Inventory:[{id:"minecraft:zombie_spawn_egg"}]}] run summon minecraft:wither ~ ~ ~
execute as @a[nbt={Inventory:[{id:"minecraft:zombie_spawn_egg"}]}] run clear @s minecraft:zombie_spawn_egg 1



execute as @a[nbt={Inventory:[{id:"minecraft:end_stone"}]}] run loot give @s loot uhc:chests/luckydice
execute as @a[nbt={Inventory:[{id:"minecraft:end_stone"}]}] run clear @s minecraft:end_stone 1