execute as @a[scores={ghead=1..}] run effect give @s minecraft:absorption 120 0
execute as @a[scores={ghead=1..}] run effect give @s minecraft:resistance 3 1
execute as @a[scores={ghead=1..}] run effect give @s minecraft:speed 5 1
execute as @a[scores={ghead=1..}] run effect give @s minecraft:instant_health 1 2
execute as @a[scores={ghead=1..}] run effect give @s minecraft:nausea 10 2
execute as @a[scores={ghead=1..}] run tellraw @s [{"text":"Golden Head Eaten","color":"gold","bold":"true"},{"text":"\nEffects Given:","color":"dark_purple","bold":"true"},{"text":"\nAbsorption","color":"gold","bold":"false"},{"text":"\nSpeed","color":"aqua","bold":"false"},{"text":"\nInstant Health","color":"dark_red","bold":"false"}]
execute at @a[scores={ghead=1..}] run playsound minecraft:block.sweet_berry_bush.place neutral @a
execute as @a[scores={ghead=1..}] run clear @s minecraft:carrot_on_a_stick 1
execute as @a[scores={ghead=1..}] run scoreboard players reset @s ghead