execute at @a[scores={heads=1..}] run loot spawn ~ ~ ~ loot uhc:blocks/player
execute at @a[scores={heads=1..}] run playsound minecraft:block.note_block.hat block @a
execute as @a[scores={heads=1..}] run scoreboard players reset @s heads