
scoreboard objectives add lightningshov minecraft.custom:minecraft.damage_dealt

execute at @a[scores={lightningshov=0..},nbt={SelectedItem:{id:"minecraft:netherite_shovel",Count:1b}}] run summon minecraft:lightning_bolt ~ ~3 ~
execute as @a[scores={lightningshov=0..},nbt={SelectedItem:{id:"minecraft:netherite_shovel",Count:1b}}] run effect give @s minecraft:resistance 1 3
execute as @a[scores={lightningshov=0..},nbt={SelectedItem:{id:"minecraft:netherite_shovel",Count:1b}}] run effect give @s minecraft:fire_resistance 1 0
scoreboard players reset @a lightningshov