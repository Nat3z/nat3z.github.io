execute as @a[scores={death=1}] run scoreboard players remove players players 1
execute as @a[scores={death=1}] if score @s death matches 1 run playsound minecraft:entity.lightning_bolt.thunder block @s
execute as @a[scores={death=1}] run title @s title {"text":"You Died!","color":"red","bold":"true"}
execute as @a[scores={death=1}] run title @s subtitle {"text":"Git Gud Nerd","color":"red","bold":"true"}
execute as @a[scores={death=1}] run gamemode spectator @s
execute as @a[scores={death=1}] run scoreboard players reset @s death