execute as @a[nbt={Inventory:[{id:"minecraft:ender_eye"}]}] run give @s minecraft:blaze_powder
execute as @a[nbt={Inventory:[{id:"minecraft:ender_eye"}]}] run give @s minecraft:ender_pearl
execute as @a[nbt={Inventory:[{id:"minecraft:ender_eye"}]}] run tellraw @s {"text":"Sorry, Eyes Of Ender Are Disabled.","color":"dark_purple"}
execute as @a[nbt={Inventory:[{id:"minecraft:ender_eye"}]}] run clear @s minecraft:ender_eye 1
execute as @a[nbt={Inventory:[{id:"minecraft:wither_skeleton_skull"}]}] run tellraw @s {"text":"Sorry, Wither Skeletons Skulls Are Disabled.","color":"dark_purple"}
execute as @a[nbt={Inventory:[{id:"minecraft:wither_skeleton_skull"}]}] run clear @s minecraft:wither_skeleton_skull