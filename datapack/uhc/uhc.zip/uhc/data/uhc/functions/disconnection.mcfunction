scoreboard objectives add disconnect minecraft.custom:minecraft.leave_game
execute as @a if score @s disconnect matches 1.. run title @a actionbar {"text":"A User Disconnected. Resetting Player Count..."}
execute as @a if score @s disconnect matches 1.. run scoreboard players reset players players
execute as @a if score @s disconnect matches 1.. run scoreboard players add players players 2
execute as @a if score @s disconnect matches 1.. run scoreboard players remove players players 1
execute as @a if score @s disconnect matches 1.. run scoreboard objectives remove disconnect