execute if score Heal FinalHeal matches 5.. run title @a actionbar [{"text":"Final Heal: ","color":"dark_green","bold":true},{"text":"|||||","color":"dark_red","bold":"true"}]
execute if score Heal FinalHeal matches 5995 run effect give @a minecraft:instant_health 1 50
execute if score Heal FinalHeal matches 5995 run effect give @a minecraft:saturation 1 50
execute if score Heal FinalHeal matches 1200.. run title @a actionbar [{"text":"Final Heal: ","color":"dark_green","bold":true},{"text":"||||","color":"dark_red","bold":"true"},{"text":"|","color":"dark_gray","bold":"true"}]
execute if score Heal FinalHeal matches 2400.. run title @a actionbar [{"text":"Final Heal: ","color":"dark_green","bold":true},{"text":"|||","color":"dark_red","bold":"true"},{"text":"||","color":"dark_gray","bold":"true"}]
execute if score Heal FinalHeal matches 3600.. run title @a actionbar [{"text":"Final Heal: ","color":"dark_green","bold":true},{"text":"||","color":"dark_red","bold":"true"},{"text":"|||","color":"dark_gray","bold":"true"}]
execute if score Heal FinalHeal matches 4800.. run title @a actionbar [{"text":"Final Heal: ","color":"dark_green","bold":true},{"text":"|","color":"dark_red","bold":"true"},{"text":"||||","color":"dark_gray","bold":"true"}]
execute if score Heal FinalHeal matches 5995.. run title @a actionbar {"text":"Final Heal Has Been Distributed","color":"dark_green","bold":"true"}
execute if score Heal FinalHeal matches 6020.. run title @a actionbar {"text":""}