# Welcome To The Battlebox Recreation Datapack!
# 
# Original Creator of Battlebox: Noxcrew
# Creator of Recreation: Nat3z_
# Custom Crafting #
# BloodLust
function uhc:custom-crafts/bloodlust
# Healing Talisman #
function uhc:custom-crafts/talismans/health
# Andrul #
function uhc:custom-crafts/andrul
# Quick Pick #
function uhc:custom-crafts/quick-pick
# Eyes Of Ender #
function uhc:disabled/eye-of-ender
# Golden Heads #
function uhc:custom-crafts/gheads
# Heads #
function uhc:custom-crafts/heads
# Fusion Set #
function uhc:custom-crafts/fusionset
function uhc:disconnection

# Auto End #
function uhc:scoreboard
function uhc:auto-end
execute as @a run attribute @s minecraft:generic.attack_speed base set 10000
execute as @a run attribute @s minecraft:generic.max_health base set 40
# FINAL HEAL #
function uhc:finalheal
# PVP ENABLED #
function uhc:pvp
# WORLD BORDER #
function uhc:worldborder
# DEATH MESSAGE #
function uhc:deathmsg
# ADVERTS #
function uhc:advertisements/index

function uhc:custom-crafts/dice

function uhc:custom-crafts/lightningsword