scoreboard objectives add Meetup-kills totalKillCount

execute if score players players-uhcmeet matches 0 run team modify uhc-meet1 suffix {"text":" Players: 0/12"}
execute as @a if score players players-uhcmeet matches 1 run team modify uhc-meet1 suffix {"text":" Players: 1/12"}
execute as @a if score players players-uhcmeet matches 2 run team modify uhc-meet1 suffix {"text":" Players: 2/12"}
execute as @a if score players players-uhcmeet matches 3 run team modify uhc-meet1 suffix {"text":" Players: 3/12"}
execute as @a if score players players-uhcmeet matches 4 run team modify uhc-meet1 suffix {"text":" Players: 4/12"}
execute as @a if score players players-uhcmeet matches 5 run team modify uhc-meet1 suffix {"text":" Players: 5/12"}
execute as @a if score players players-uhcmeet matches 6 run team modify uhc-meet1 suffix {"text":" Players: 6/12"}
execute as @a if score players players-uhcmeet matches 7 run team modify uhc-meet1 suffix {"text":" Players: 7/12"}
execute as @a if score players players-uhcmeet matches 8 run team modify uhc-meet1 suffix {"text":" Players: 8/12"}
execute as @a if score players players-uhcmeet matches 9 run team modify uhc-meet1 suffix {"text":" Players: 9/12"}
execute as @a if score players players-uhcmeet matches 10 run team modify uhc-meet1 suffix {"text":" Players: 10/12"}
execute as @a if score players players-uhcmeet matches 11 run team modify uhc-meet1 suffix {"text":" Players: 11/12"}
execute as @a if score players players-uhcmeet matches 12 run team modify uhc-meet1 suffix {"text":" Players: 12/12"}