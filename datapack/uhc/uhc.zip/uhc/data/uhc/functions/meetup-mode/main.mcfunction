execute if score Timer uhc-meetTimers matches 98.. if score players players-uhcmeet matches 1 run playsound minecraft:entity.arrow.hit_player block @a
execute if score Timer uhc-meetTimers matches 100.. if score players players-uhcmeet matches 1 run title @a title {"text":"[!] Victory Royale [!]","color":"dark_green"}
execute if score Timer uhc-meetTimers matches 100.. if score players players-uhcmeet matches 1 run clear @a
execute as @a if score Timer uhc-meetTimers matches 100.. if score players players-uhcmeet matches 1 run replaceitem entity @s hotbar.4 minecraft:chest{display:{Name:'{"text":"Choose A UHC Gamemode","color":"gold","bold":true}'},Enchantments:[{}]}
execute if score Timer uhc-meetTimers matches 100.. if score players players-uhcmeet matches 1 run scoreboard objectives remove uhc-meetTimers
execute if score Timer uhc-meetTimers matches 100.. if score players players-uhcmeet matches 1 run scoreboard players reset players players-uhcmeet
scoreboard players add Timer uhc-meetTimers 1






execute as @a[scores={death-uhcmeet=1..}] run scoreboard players remove players players-uhcmeet 1
execute as @a[scores={death-uhcmeet=1..}] run scoreboard players reset @s death-uhcmeet



function uhc:meetup-mode/kill-check/check


execute if score Timer uhc-meetTimers matches 2 run title @a title {"text":"Welcome To UHC Meetup!","color":"gold"}


execute if score Timer uhc-meetTimers matches 20 run title @a actionbar {"text":"9 Seconds Left Till The Brawl Begins!"}
execute if score Timer uhc-meetTimers matches 40 run title @a actionbar {"text":"8 Seconds Left Till The Brawl Begins!"}
execute if score Timer uhc-meetTimers matches 60 run title @a actionbar {"text":"7 Seconds Left Till The Brawl Begins!"}
execute if score Timer uhc-meetTimers matches 80 run title @a actionbar {"text":"6 Seconds Left Till The Brawl Begins!"}
execute if score Timer uhc-meetTimers matches 100 run title @a actionbar {"text":"5 Seconds Left Till The Brawl Begins!"}
execute at @a if score Timer uhc-meetTimers matches 100 run playsound minecraft:entity.arrow.hit_player block @a
execute if score Timer uhc-meetTimers matches 120 run title @a actionbar {"text":"4 Seconds Left Till The Brawl Begins!"}
execute at @a if score Timer uhc-meetTimers matches 120 run playsound minecraft:entity.arrow.hit_player block @a
execute if score Timer uhc-meetTimers matches 140 run title @a actionbar {"text":"3 Seconds Left Till The Brawl Begins!"}
execute at @a if score Timer uhc-meetTimers matches 140 run playsound minecraft:entity.arrow.hit_player block @a
execute if score Timer uhc-meetTimers matches 160 run title @a actionbar {"text":"2 Seconds Left Till The Brawl Begins!"}
execute at @a if score Timer uhc-meetTimers matches 160 run playsound minecraft:entity.arrow.hit_player block @a
execute at @a if score Timer uhc-meetTimers matches 180 run playsound minecraft:entity.arrow.hit_player block @a
execute if score Timer uhc-meetTimers matches 180 run title @a actionbar {"text":"1 Seconds Left Till The Brawl Begins!"}
execute at @a if score Timer uhc-meetTimers matches 200 at @a run playsound minecraft:entity.ender_dragon.growl block @a
execute if score Timer uhc-meetTimers matches 200 run gamemode survival @a
execute if score Timer uhc-meetTimers matches 200 run title @a title {"text":"The Game Has Begun."}

execute if score Timer uhc-meetTimers matches 3000 run tellraw @a [{"text":"<UHC Meetup>","color":"gold"},{"text":" Strength Has Been Given To Everyone.","color":"gray"}]
execute if score Timer uhc-meetTimers matches 3000 run effect give @a minecraft:strength 10000 0