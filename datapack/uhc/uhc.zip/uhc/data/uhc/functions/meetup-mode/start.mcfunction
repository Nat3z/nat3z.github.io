worldborder set 50 0
worldborder set 15 500

kill @e[type=item]

effect clear @a
clear @a
effect give @a minecraft:instant_health 1 50
effect give @a minecraft:saturation 1 50
effect give @a minecraft:weakness 10 100
effect give @a minecraft:speed 10 1
effect give @a minecraft:jump_boost 10 0

scoreboard players reset players players-uhcmeet
scoreboard players reset @a death-uhcmeet
scoreboard objectives add death-uhcmeet deathCount
scoreboard objectives add uhc-meetTimers dummy
scoreboard players reset Timer uhc-meetTimers
scoreboard objectives add players-uhcmeet dummy
gamerule fallDamage false
execute as @a run scoreboard players add players players-uhcmeet 1

execute as @a run tp 0 ~70 0

give @a diamond_sword{display:{Name:'{"text":"Diamond Sword (UHC Meetup)"}'},Enchantments:[{id:"minecraft:sharpness",lvl:1s},{id:"minecraft:unbreaking",lvl:2s}]} 1
give @a minecraft:golden_apple 3
give @a minecraft:carrot_on_a_stick 1
give @a minecraft:oak_planks 64
give @a minecraft:water_bucket 1
give @a minecraft:lava_bucket 1
give @a minecraft:anvil 1
give @a minecraft:experience_bottle 64
execute as @a run replaceitem entity @s armor.chest minecraft:diamond_chestplate
execute as @a run replaceitem entity @s armor.feet minecraft:diamond_boots
execute as @a run replaceitem entity @s armor.legs minecraft:diamond_leggings
execute as @a run replaceitem entity @s armor.head minecraft:diamond_helmet
give @a minecraft:cooked_beef 64
give @a minecraft:gold_ingot 64
gamemode adventure @a

scoreboard objectives add UHCMeet-1 dummy {"text":"UHC Meetup","color":"gold"}

team add uhc-meet1

team modify uhc-meet1 color gold

scoreboard objectives setdisplay sidebar UHCMeet-1

scoreboard players set Total Meetup-kills 12

scoreboard players add Total UHCMeet-1 12

team join uhc-meet1 Total