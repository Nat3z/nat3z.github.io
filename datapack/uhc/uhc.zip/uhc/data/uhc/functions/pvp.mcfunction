execute if score Heal FinalHeal matches 7996.. run title @a actionbar {"text":"PVP Has Been Enabled, Good Luck...","color":"dark_red","bold":"true"}
execute if score Heal FinalHeal matches 7996.. at @a run playsound minecraft:ambient.cave block @a
execute if score Heal FinalHeal matches 7995 run team remove all
execute if score Heal FinalHeal matches 8000 run scoreboard objectives remove FinalHeal