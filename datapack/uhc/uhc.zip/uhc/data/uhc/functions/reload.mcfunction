# Welcome To The Bedwars Recreation Datapack!
# 
# Original Creator of Bedwars: Hypixel
# Creator of Recreation: Nat3z_
tellraw @a [{"text":"Welcome To UHC","color":"gold","bold":true}]

clear @a

replaceitem entity @a hotbar.4 minecraft:chest{display:{Name:'{"text":"Choose A UHC Gamemode","color":"gold","bold":true}'},Enchantments:[{}]}