scoreboard objectives add uhc dummy {"text":"UHC","color":"gold"}
team add scoreboard
team join scoreboard §6Players
execute if score players players matches 1 run team modify scoreboard suffix {"text":": 1/12","color":"gold"}
execute if score players players matches 2 run team modify scoreboard suffix {"text":": 2/12","color":"gold"}
execute if score players players matches 3 run team modify scoreboard suffix {"text":": 3/12","color":"gold"}
execute if score players players matches 4 run team modify scoreboard suffix {"text":": 4/12","color":"gold"}
execute if score players players matches 5 run team modify scoreboard suffix {"text":": 5/12","color":"gold"}
execute if score players players matches 6 run team modify scoreboard suffix {"text":": 6/12","color":"gold"}
execute if score players players matches 7 run team modify scoreboard suffix {"text":": 7/12","color":"gold"}
execute if score players players matches 8 run team modify scoreboard suffix {"text":": 8/12","color":"gold"}
execute if score players players matches 9 run team modify scoreboard suffix {"text":": 9/12","color":"gold"}
execute if score players players matches 10 run team modify scoreboard suffix {"text":": 10/12","color":"gold"}
execute if score players players matches 11 run team modify scoreboard suffix {"text":": 11/12","color":"gold"}
execute if score players players matches 12 run team modify scoreboard suffix {"text":": 12/12 MAX","color":"gold"}
execute if score players players matches 13 run scoreboard players set players players 12

scoreboard players set §6Players uhc 12