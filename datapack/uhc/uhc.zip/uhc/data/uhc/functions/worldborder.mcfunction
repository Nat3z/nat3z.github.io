scoreboard players add Worldborder WorldBordertimer 1
scoreboard players add Heal FinalHeal 1
execute if score Worldborder WorldBordertimer matches 11978 run worldborder set 15 600
execute if score Worldborder WorldBordertimer matches 11978 run title @a actionbar {"text":"World Border Shrinking","color":"dark_red"}
execute if score Worldborder WorldBordertimer matches 23996 run title @a title {"text":"World Border Is Now Maxed.","color":"dark_red"}
execute if score Worldborder WorldBordertimer matches 23996 run title @a subtitle {"text":"In 2 Minutes, There Will Be No Winner..","color":"dark_red"}
execute at @r[] if score Worldborder WorldBordertimer matches 23996 run playsound minecraft:music_disc.pigstep block @a ~ ~ ~ 10 1 1
execute if score Worldborder WorldBordertimer matches 23996.. run title @a actionbar {"text":"[ || ]","color":"dark_red","bold":"true"}
execute if score Worldborder WorldBordertimer matches 24200.. run title @a actionbar [{"text":"[ |","color":"dark_red","bold":"true"},{"text":"|","color":"dark_gray","bold":"true"},{"text":" ]","color":"dark_red","bold":"true"}]
execute if score Worldborder WorldBordertimer matches 25396.. run title @a title {"text":"No Winner.","color":"red","bold":"true"}
execute if score Worldborder WorldBordertimer matches 25168.. run title @a subtitle {"text":"You Took Too Long!","color":"red","bold":"true"}
execute if score Worldborder WorldBordertimer matches 25168 run kill @a
execute if score Worldborder WorldBordertimer matches 25168 run stopsound @a * minecraft:music_disc.pigstep
execute if score Worldborder WorldBordertimer matches 25168.. run scoreboard objectives remove WorldBordertimer